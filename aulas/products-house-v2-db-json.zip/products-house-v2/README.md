# products-house-v2

Criar rotas:

/produtos
    -Deve retornar a view de produto



Tarefa:
/login
    -Deve retornar a view de login

/cadastro
    deve retornar a view de cadastro